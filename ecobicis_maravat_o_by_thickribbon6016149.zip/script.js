import * as L from 'leaflet';

// Coordinates for Maravatío, Michoacán (Approximate)
const maravatioCoords = [19.8955, -100.4451];
const initialZoom = 14; // Zoom level to show the town

// Initialize the map
const map = L.map('map').setView(maravatioCoords, initialZoom);

// Add a tile layer (OpenStreetMap)
L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    maxZoom: 19,
    attribution: '&copy; <a href="http://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
}).addTo(map);

// --- Bike Station Markers ---
// Define a custom icon (optional, using default for simplicity now)
// const bikeIcon = L.icon({
//     iconUrl: 'path/to/bike-icon.png', // Replace with an actual icon if you have one
//     iconSize: [38, 38],
//     iconAnchor: [19, 38],
//     popupAnchor: [0, -40]
// });

// Add markers for potential EcoBici locations
// (Replace these with actual coordinates when known)
const stations = [
    { coords: [19.8960, -100.4455], name: "Estación Centro Histórico" },
    { coords: [19.8995, -100.4480], name: "Estación Parque Alameda" },
    { coords: [19.8920, -100.4420], name: "Estación Mercado Municipal" },
    { coords: [19.9010, -100.4400], name: "Estación Deportiva Melchor Ocampo" }, // Example locations
    // Adding more stations, further apart
    { coords: [19.9055, -100.4510], name: "Estación Norte (Salida a Acámbaro)" },
    { coords: [19.8880, -100.4495], name: "Estación Sur (Cerca de IMSS)" },
    { coords: [19.8935, -100.4350], name: "Estación Este (Colonia El Chirimoyo)" },
    { coords: [19.8970, -100.4550], name: "Estación Oeste (Salida a Morelia)" }
];

stations.forEach(station => {
    L.marker(station.coords /*, {icon: bikeIcon} */) // Add icon here if using a custom one
     .addTo(map)
     .bindPopup(`<b>${station.name}</b><br>EcoBicis disponibles aquí.`);
});

// Add a marker for the center (optional)
// L.marker(maravatioCoords).addTo(map)
//     .bindPopup('Centro de Maravatío.');